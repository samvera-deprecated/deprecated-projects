require 'spec_helper'

describe "" do
  it "should" do
    true.should be_true
  end
end
