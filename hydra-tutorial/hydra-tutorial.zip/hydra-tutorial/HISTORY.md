h3. 0.2.1

* Minor edits to various messages and user prompts.
* Improved the index view.
* Modified edit view to agree with Record model.
* Added the --thru option, mainly for developer use.

h3. 0.2.0

* Added ability to run tutorial step-by-step.
* Added Git to generated Rails app so user can diff changes between steps.

h3. 0.1.0

* Initial versions.
