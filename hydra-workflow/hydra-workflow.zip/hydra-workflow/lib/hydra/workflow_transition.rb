class Hydra::WorkflowTransition
end