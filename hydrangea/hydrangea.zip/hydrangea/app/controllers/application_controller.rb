require_dependency 'vendor/plugins/blacklight/app/controllers/application_controller.rb'
require_dependency 'vendor/plugins/hydra_repository/app/controllers/application_controller.rb'
class ApplicationController < ActionController::Base
  
end