
describe 'YourLib'
  describe '.someMethod()'
    it 'should do something'
      true.should.be true
    end
  end
end