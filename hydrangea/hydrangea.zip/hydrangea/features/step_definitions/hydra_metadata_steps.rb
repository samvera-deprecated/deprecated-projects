Then /^the "([^"]*)" field for the "([^"]*)" entry should contain "([^"]*)"$/ do |arg1, arg2, arg3|
  pending # express the regexp above with the code you wish you had
end
