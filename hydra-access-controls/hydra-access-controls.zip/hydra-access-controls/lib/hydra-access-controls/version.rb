module Hydra
  module Access
    module Controls
      VERSION = "0.0.2"
    end
  end
end
