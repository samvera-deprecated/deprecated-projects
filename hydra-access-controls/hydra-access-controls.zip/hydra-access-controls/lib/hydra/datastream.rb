module Hydra
  module Datastream
    extend ActiveSupport::Autoload
    autoload :RightsMetadata
    autoload :InheritableRightsMetadata
  end
end
