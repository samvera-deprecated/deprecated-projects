# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = 'a94abaacb01d84e8e1c1afe65947157613967c3bc79fb2f6ba40576ad5a1e243d1c7bc10b5601e45e1641f7be3db6d094c52470c29fc9f734f17788f3c3a9d50';
